import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Plus, Menu, X, LogOut, Trash2 } from "lucide-react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface ChatLayoutProps {
  children: React.ReactNode;
  conversationId?: number;
}

export function ChatLayout({ children, conversationId }: ChatLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const { data: conversations = [] } = trpc.chat.listConversations.useQuery(undefined, {
    enabled: !!user,
  });

  const createConvMutation = trpc.chat.createConversation.useMutation({
    onSuccess: (conv) => {
      navigate(`/chat/${conv.id}`);
      setMobileOpen(false);
    },
  });

  const deleteConvMutation = trpc.chat.deleteConversation.useMutation({
    onSuccess: () => {
      navigate("/");
    },
  });

  const handleNewChat = () => {
    createConvMutation.mutate({});
  };

  const handleDeleteConversation = (id: number, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Tem certeza que deseja deletar esta conversa?")) {
      deleteConvMutation.mutate({ conversationId: id });
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={cn(
          "fixed lg:relative w-64 h-screen bg-sidebar text-sidebar-foreground border-r border-sidebar-border flex flex-col transition-transform duration-300 z-50",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Header */}
        <div className="p-4 border-b border-sidebar-border flex items-center justify-between">
          <h1 className="text-xl font-bold text-sidebar-primary">Dude</h1>
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden p-1 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground rounded"
          >
            <X size={20} />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-4 border-b border-sidebar-border">
          <Button
            onClick={handleNewChat}
            disabled={createConvMutation.isPending}
            className="w-full bg-sidebar-primary hover:bg-sidebar-primary/90 text-sidebar-primary-foreground"
          >
            <Plus size={18} className="mr-2" />
            Novo chat
          </Button>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {conversations.length === 0 ? (
            <div className="p-4 text-center text-sidebar-foreground/60 text-sm">
              Nenhuma conversa ainda
            </div>
          ) : (
            <div className="p-2">
              {conversations.map((conv) => (
                <div
                  key={conv.id}
                  className={cn(
                    "w-full text-left p-3 rounded-lg mb-2 transition-colors truncate group flex items-center justify-between cursor-pointer",
                    conversationId === conv.id
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "hover:bg-sidebar-accent/20 text-sidebar-foreground"
                  )}
                  onClick={() => {
                    navigate(`/chat/${conv.id}`);
                    setMobileOpen(false);
                  }}
                >
                  <span className="truncate flex-1">{conv.title}</span>
                  <button
                    onClick={(e) => handleDeleteConversation(conv.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:bg-destructive/20 rounded transition-opacity"
                  >
                    <Trash2 size={16} className="text-destructive" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* User Info & Logout */}
        <div className="p-4 border-t border-sidebar-border">
          {user && (
            <div className="mb-3">
              <p className="text-sm font-medium truncate">{user.name || user.email}</p>
              <p className="text-xs text-sidebar-foreground/60 truncate">{user.email}</p>
            </div>
          )}
          <Button
            onClick={handleLogout}
            variant="outline"
            className="w-full border-sidebar-border text-sidebar-foreground hover:bg-sidebar-accent/20"
          >
            <LogOut size={18} className="mr-2" />
            Sair
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <div className="lg:hidden flex items-center justify-between p-4 border-b border-border bg-card">
          <button
            onClick={() => setMobileOpen(true)}
            className="p-2 hover:bg-muted rounded"
          >
            <Menu size={20} />
          </button>
          <h1 className="text-lg font-bold text-primary">Dude</h1>
          <div className="w-10" />
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">{children}</div>
      </div>
    </div>
  );
}

