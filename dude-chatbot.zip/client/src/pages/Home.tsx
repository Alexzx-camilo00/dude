import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { MessageCircle, Image, Music, Video, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const createConvMutation = trpc.chat.createConversation.useMutation({
    onSuccess: (conv) => {
      navigate(`/chat/${conv.id}`);
    },
  });

  // Redirect to chat if authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      // Create a new conversation and navigate
      createConvMutation.mutate({});
    }
  }, [isAuthenticated, user]);

  if (isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
            <MessageCircle className="w-8 h-8 text-primary animate-pulse" />
          </div>
          <p className="text-muted-foreground">Carregando seu chat...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted flex flex-col">
      {/* Header */}
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">D</span>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Dude</h1>
          </div>
          <Button
            onClick={() => window.location.href = getLoginUrl()}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            Entrar
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Converse com <span className="text-primary">Dude</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Um assistente de IA poderoso que entende texto, imagens, áudio e vídeo. Faça perguntas, analise conteúdo e obtenha respostas instantâneas.
          </p>
          <Button
            onClick={() => window.location.href = getLoginUrl()}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            Começar agora
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <div className="bg-card border border-border rounded-lg p-6 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-4">
              <MessageCircle className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">Conversas Naturais</h3>
            <p className="text-sm text-muted-foreground">
              Converse de forma natural e obtenha respostas inteligentes
            </p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-4">
              <Image className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">Análise de Imagens</h3>
            <p className="text-sm text-muted-foreground">
              Envie imagens e receba análises detalhadas
            </p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-4">
              <Music className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">Processamento de Áudio</h3>
            <p className="text-sm text-muted-foreground">
              Transcreva e analise arquivos de áudio
            </p>
          </div>

          <div className="bg-card border border-border rounded-lg p-6 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/10 rounded-lg mb-4">
              <Video className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground mb-2">Entendimento de Vídeo</h3>
            <p className="text-sm text-muted-foreground">
              Analise vídeos e obtenha insights
            </p>
          </div>
        </div>

        {/* Capabilities Section */}
        <div className="bg-card border border-border rounded-lg p-8 mb-16">
          <div className="flex items-center gap-3 mb-6">
            <Zap className="w-6 h-6 text-primary" />
            <h3 className="text-2xl font-bold text-foreground">Funcionalidades</h3>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-foreground">Histórico de conversas salvo automaticamente</span>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-foreground">Suporte a múltiplos tipos de mídia</span>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-foreground">Interface responsiva para mobile e desktop</span>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-foreground">Respostas rápidas e precisas</span>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-foreground">Contexto preservado em cada conversa</span>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
              <span className="text-foreground">Design moderno e intuitivo</span>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-6 text-center text-muted-foreground">
        <p>Dude - Seu assistente de IA inteligente</p>
      </footer>
    </div>
  );
}

