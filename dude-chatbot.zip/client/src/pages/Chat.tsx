import { useState, useEffect, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { ChatLayout } from "@/components/ChatLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Paperclip, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  mediaUrls?: string[];
  mediaTypes?: string[];
  createdAt: Date;
}

export default function Chat() {
  const { conversationId } = useParams<{ conversationId: string }>();
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isRedirecting, setIsRedirecting] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const convId = conversationId ? parseInt(conversationId, 10) : null;

  const { data: chatData, error: chatError, isLoading: isChatLoading } = trpc.chat.getConversation.useQuery(
    { conversationId: convId! },
    { enabled: !!convId && !!user && !isRedirecting }
  );

  const createConversationMutation = trpc.chat.createConversation.useMutation({
    onSuccess: (newConversation) => {
      setIsRedirecting(false);
      setLocation(`/chat/${newConversation.id}`);
    },
    onError: () => {
      setIsRedirecting(false);
    },
  });

  const sendMessageMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: (result) => {
      setMessages((prev) => [
        ...prev,
        {
          id: result.message.id,
          role: "assistant",
          content: result.content,
          mediaUrls: result.message.mediaUrls,
          mediaTypes: result.message.mediaTypes,
          createdAt: result.message.createdAt,
        },
      ]);
      setInput("");
      setSelectedFiles([]);
      setIsLoading(false);
    },
    onError: (error) => {
      console.error("Error sending message:", error);
      setIsLoading(false);
    },
  });

  useEffect(() => {
    if (chatData?.messages) {
      setMessages(chatData.messages);
    }
  }, [chatData]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Handle conversation not found error
  useEffect(() => {
    if (chatError && !isRedirecting) {
      // Check if error is about conversation not found
      const errorMessage = chatError.message || "";
      if (errorMessage.toLowerCase().includes("conversation not found") || 
          errorMessage.toLowerCase().includes("unauthorized")) {
        setIsRedirecting(true);
        // Create a new conversation
        createConversationMutation.mutate({ title: undefined });
      }
    }
  }, [chatError, isRedirecting]);

  const handleSendMessage = async () => {
    if (!input.trim() || !convId || isLoading) return;

    const userMessage: Message = {
      id: Date.now(),
      role: "user",
      content: input,
      mediaUrls: selectedFiles.length > 0 ? selectedFiles.map(() => "") : undefined,
      mediaTypes: selectedFiles.length > 0 ? selectedFiles.map((f) => f.type) : undefined,
      createdAt: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    sendMessageMutation.mutate({
      conversationId: convId,
      content: input,
      mediaUrls: selectedFiles.length > 0 ? selectedFiles.map(() => "") : undefined,
      mediaTypes: selectedFiles.length > 0 ? selectedFiles.map((f) => f.type) : undefined,
    });
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(files);
  };

  if (!convId) {
    return (
      <ChatLayout>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <p className="text-muted-foreground">Selecione uma conversa ou crie uma nova</p>
          </div>
        </div>
      </ChatLayout>
    );
  }

  // Show loading state while fetching conversation
  if (isChatLoading || isRedirecting) {
    return (
      <ChatLayout conversationId={convId}>
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <Loader2 className="animate-spin mx-auto mb-4" size={32} />
            <p className="text-muted-foreground">
              {isRedirecting ? "Criando nova conversa..." : "Carregando conversa..."}
            </p>
          </div>
        </div>
      </ChatLayout>
    );
  }

  return (
    <ChatLayout conversationId={convId}>
      <div className="flex flex-col h-full">
        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <h2 className="text-2xl font-bold text-primary mb-2">Olá! Eu sou o Dude</h2>
                <p className="text-muted-foreground mb-4">
                  Como posso ajudá-lo hoje?
                </p>
                <div className="text-sm text-muted-foreground mt-6 space-y-2">
                  <p>💡 Dicas:</p>
                  <p>• Digite normalmente para conversar</p>
                  <p>• Use "/imagine" para gerar imagens</p>
                  <p>• Anexe imagens, áudio ou vídeo para análise</p>
                </div>
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={cn(
                    "flex message-enter",
                    message.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  <div
                    className={cn(
                      "max-w-xs lg:max-w-md xl:max-w-lg px-4 py-2 rounded-lg",
                      message.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-none"
                        : "bg-card text-card-foreground border border-border rounded-bl-none"
                    )}
                  >
                    <p className="whitespace-pre-wrap break-words">{message.content}</p>
                    
                    {/* Display images */}
                    {message.mediaUrls && message.mediaUrls.length > 0 && message.mediaTypes?.some(t => t.startsWith("image/")) && (
                      <div className="mt-3 space-y-2">
                        {message.mediaUrls.map((url, idx) => {
                          if (message.mediaTypes?.[idx].startsWith("image/")) {
                            return (
                              <img
                                key={idx}
                                src={url}
                                alt="Generated image"
                                className="rounded-lg max-w-full h-auto"
                              />
                            );
                          }
                          return null;
                        })}
                      </div>
                    )}

                    {/* Display file indicators */}
                    {message.mediaUrls && message.mediaUrls.length > 0 && message.mediaTypes?.some(t => !t.startsWith("image/")) && (
                      <div className="mt-2 flex gap-2 flex-wrap">
                        {message.mediaTypes?.map((type, idx) => {
                          if (!type.startsWith("image/")) {
                            return (
                              <div
                                key={idx}
                                className="text-xs bg-black/20 px-2 py-1 rounded"
                              >
                                {type.startsWith("audio/") && "🎧"}
                                {type.startsWith("video/") && "📹"}
                              </div>
                            );
                          }
                          return null;
                        })}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-card text-card-foreground border border-border px-4 py-2 rounded-lg rounded-bl-none">
                    <div className="flex gap-2">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t border-border bg-card p-4">
          {selectedFiles.length > 0 && (
            <div className="mb-3 flex gap-2 flex-wrap">
              {selectedFiles.map((file, idx) => (
                <div
                  key={idx}
                  className="bg-muted text-muted-foreground text-xs px-2 py-1 rounded flex items-center gap-1"
                >
                  {file.type.startsWith("image/") && "📷"}
                  {file.type.startsWith("audio/") && "🎧"}
                  {file.type.startsWith("video/") && "📹"}
                  {file.name}
                </div>
              ))}
            </div>
          )}
          <div className="flex gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
              title="Anexar arquivo"
            >
              <Paperclip size={20} className="text-muted-foreground" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,audio/*,video/*"
              onChange={handleFileSelect}
              className="hidden"
            />
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="Digite sua mensagem... (use /imagine para gerar imagens)"
              disabled={isLoading}
              className="flex-1"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!input.trim() || isLoading}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {isLoading ? (
                <Loader2 size={20} className="animate-spin" />
              ) : (
                <Send size={20} />
              )}
            </Button>
          </div>
        </div>
      </div>
    </ChatLayout>
  );
}

