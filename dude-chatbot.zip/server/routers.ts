import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { generateResponse, generateImage } from "./gemini";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    // Get all conversations for the current user
    listConversations: protectedProcedure.query(async ({ ctx }) => {
      return db.getConversations(ctx.user.id);
    }),

    // Get a specific conversation with all messages
    getConversation: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ ctx, input }) => {
        const conversation = await db.getConversation(input.conversationId, ctx.user.id);
        if (!conversation) {
          throw new Error("Conversation not found");
        }

        const msgs = await db.getMessagesParsed(input.conversationId);
        return {
          conversation,
          messages: msgs,
        };
      }),

    // Create a new conversation
    createConversation: protectedProcedure
      .input(z.object({ title: z.string().optional() }))
      .mutation(async ({ ctx, input }) => {
        const title = input.title || `Chat ${new Date().toLocaleDateString()}`;
        return db.createConversation(ctx.user.id, title);
      }),

    // Update conversation title
    updateConversationTitle: protectedProcedure
      .input(z.object({ conversationId: z.number(), title: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await db.updateConversationTitle(input.conversationId, ctx.user.id, input.title);
        return { success: true };
      }),

    // Delete a conversation
    deleteConversation: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await db.deleteConversation(input.conversationId, ctx.user.id);
        return { success: true };
      }),

    // Send a message and get response
    sendMessage: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          content: z.string(),
          mediaUrls: z.array(z.string()).optional(),
          mediaTypes: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Verify conversation belongs to user
        const conversation = await db.getConversation(input.conversationId, ctx.user.id);
        if (!conversation) {
          throw new Error("Conversation not found");
        }

        // Save user message
        await db.createMessage(
          input.conversationId,
          "user",
          input.content,
          input.mediaUrls,
          input.mediaTypes
        );

        // Get conversation history for context
        const messages = await db.getMessagesParsed(input.conversationId);

        // Check if user is requesting image generation
        const isImageRequest = input.content.toLowerCase().includes("/imagine") || 
                              input.content.toLowerCase().includes("gera uma imagem") ||
                              input.content.toLowerCase().includes("cria uma imagem") ||
                              input.content.toLowerCase().includes("desenha") ||
                              input.content.toLowerCase().includes("ilustra");

        let response: string;
        let imageUrl: string | undefined;

        if (isImageRequest) {
          try {
            // Extract the image prompt (remove the /imagine command if present)
            const imagePrompt = input.content
              .replace(/\/imagine\s*/i, "")
              .replace(/gera uma imagem\s*/i, "")
              .replace(/cria uma imagem\s*/i, "")
              .trim();

            if (!imagePrompt) {
              response = "Por favor, descreva a imagem que você gostaria que eu gerasse! Exemplo: '/imagine um gato fofo em um sofá'";
            } else {
              imageUrl = await generateImage(imagePrompt);
              response = `Criei uma imagem baseada na sua descrição: "${imagePrompt}"`;
            }
          } catch (error) {
            response = `Desculpe, não consegui gerar a imagem. Erro: ${error instanceof Error ? error.message : "Erro desconhecido"}`;
          }
        } else {
          // Generate response from Gemini with Portuguese system prompt
          const systemPrompt = "Você é o Dude, um assistente de IA útil, amigável e inteligente. Você pode processar texto, imagens, áudio e vídeo. Responda sempre em português de forma conversacional e natural. Ajude os usuários com suas perguntas e tarefas. Seja conciso, amigável e direto nas respostas. Se o usuário pedir para gerar uma imagem, você pode usar o comando /imagine seguido da descrição.";
          
          response = await generateResponse(
            messages.map(m => ({
              role: m.role,
              content: m.content,
              mediaUrls: m.mediaUrls,
              mediaTypes: m.mediaTypes,
            })),
            systemPrompt
          );
        }

        // Save assistant response
        const assistantMessage = await db.createMessage(
          input.conversationId,
          "assistant",
          response,
          imageUrl ? [imageUrl] : undefined,
          imageUrl ? ["image/png"] : undefined
        );
        
        // Parse media URLs and types for response
        const parsedMediaUrls = assistantMessage.mediaUrls ? JSON.parse(assistantMessage.mediaUrls) as string[] : undefined;
        const parsedMediaTypes = assistantMessage.mediaTypes ? JSON.parse(assistantMessage.mediaTypes) as string[] : undefined;

        // Update conversation title if it's the first message
        if (messages.length === 1) {
          const title = input.content.substring(0, 50) + (input.content.length > 50 ? "..." : "");
          await db.updateConversationTitle(input.conversationId, ctx.user.id, title);
        }

        return {
          message: {
            ...assistantMessage,
            mediaUrls: parsedMediaUrls,
            mediaTypes: parsedMediaTypes,
          },
          content: response,
          imageUrl,
        };
      }),

    // Generate image endpoint
    generateImage: protectedProcedure
      .input(z.object({ prompt: z.string() }))
      .mutation(async ({ ctx, input }) => {
        try {
          const imageUrl = await generateImage(input.prompt);
          return { success: true, imageUrl };
        } catch (error) {
          throw new Error(`Failed to generate image: ${error instanceof Error ? error.message : String(error)}`);
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;

