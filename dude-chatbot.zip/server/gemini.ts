import { GoogleGenerativeAI } from "@google/generative-ai";
import { ENV } from "./_core/env";
import { storagePut } from "./storage";

// Initialize client with API key from environment
const apiKey = ENV.geminiApiKey;

if (!apiKey) {
  console.warn("[Gemini] GEMINI_API_KEY not configured in environment");
}

const client = new GoogleGenerativeAI(apiKey || "");

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
  mediaUrls?: string[];
  mediaTypes?: string[];
}

export async function generateResponse(
  messages: ChatMessage[],
  systemPrompt: string = "You are Dude, a helpful AI assistant. Respond in a friendly and conversational manner."
): Promise<string> {
  try {
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not configured");
    }

    const model = client.getGenerativeModel({ model: "gemini-2.5-flash" });

    // Convert messages to Gemini format
    const contents = messages.map(msg => {
      const parts: any[] = [];

      // Add text content
      if (msg.content) {
        parts.push({ text: msg.content });
      }

      return {
        role: msg.role === "user" ? "user" : "model",
        parts,
      };
    });

    // Generate response
    const response = await model.generateContent({
      contents,
      systemInstruction: systemPrompt,
    });

    const text = response.response.text();
    return text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error(`Failed to generate response from Gemini API: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function generateResponseStream(
  messages: ChatMessage[],
  systemPrompt: string = "You are Dude, a helpful AI assistant. Respond in a friendly and conversational manner."
) {
  try {
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not configured");
    }

    const model = client.getGenerativeModel({ model: "gemini-2.5-flash" });

    // Convert messages to Gemini format
    const contents = messages.map(msg => {
      const parts: any[] = [];

      if (msg.content) {
        parts.push({ text: msg.content });
      }

      return {
        role: msg.role === "user" ? "user" : "model",
        parts,
      };
    });

    // Generate streaming response
    const stream = await model.generateContentStream({
      contents,
      systemInstruction: systemPrompt,
    });

    return stream;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error(`Failed to generate streaming response from Gemini API: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function generateImage(prompt: string): Promise<string> {
  try {
    if (!ENV.forgeApiUrl) {
      throw new Error("BUILT_IN_FORGE_API_URL is not configured");
    }
    if (!ENV.forgeApiKey) {
      throw new Error("BUILT_IN_FORGE_API_KEY is not configured");
    }

    // Use the built-in image generation from Manus
    const baseUrl = ENV.forgeApiUrl.endsWith("/")
      ? ENV.forgeApiUrl
      : `${ENV.forgeApiUrl}/`;
    const fullUrl = new URL(
      "images.v1.ImageService/GenerateImage",
      baseUrl
    ).toString();

    const response = await fetch(fullUrl, {
      method: "POST",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
        "connect-protocol-version": "1",
        authorization: `Bearer ${ENV.forgeApiKey}`,
      },
      body: JSON.stringify({
        prompt: prompt,
        original_images: [],
      }),
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      throw new Error(
        `Image generation request failed (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
      );
    }

    const result = (await response.json()) as {
      image: {
        b64Json: string;
        mimeType: string;
      };
    };
    
    const base64Data = result.image.b64Json;
    const buffer = Buffer.from(base64Data, "base64");

    // Save to S3
    const { url } = await storagePut(
      `generated/${Date.now()}-${Math.random().toString(36).substring(7)}.png`,
      buffer,
      result.image.mimeType
    );
    
    return url;
  } catch (error) {
    console.error("Error generating image:", error);
    throw new Error(`Failed to generate image: ${error instanceof Error ? error.message : String(error)}`);
  }
}

